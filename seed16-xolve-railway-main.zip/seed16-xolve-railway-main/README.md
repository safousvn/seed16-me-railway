# Seed 1.6 Auto Runner
A small Python app that calls the Seed 1.6 model repeatedly to simulate load and consume tokens.

## How to deploy
1. Create a new project on Railway.app
2. Upload these files
3. Set environment variable ARK_API_KEY in Railway’s Dashboard
4. Deploy and click "Run app"
